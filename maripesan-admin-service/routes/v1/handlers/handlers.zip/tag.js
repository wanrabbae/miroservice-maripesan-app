import pkg from '@prisma/client';
const { PrismaClient } = pkg;

const prisma = new PrismaClient();

// Tag
const viewTag = async (req, res) => {
    const query = await prisma.tag.findMany()

      return res.json({
        status: 'success',
        message: 'Data Showed',
        data: query
    });    
}

const createTag = async (req, res) => {
    const query = await prisma.tag.create({
        data: {
            tag: req.body.tag,
            image_url: req.body.image_url,
        }
    })
    
    return res.json({
        status: 'success',
        message: 'Data Created',
    })
}

const editTag = async (req, res) => {
    const {tag_id} = req.params.id
    if(tag_id == null){
        return res.status(409).json({
            status: 'error',
            message: 'ID cannot be NULL',
        })
    }
    const query = await prisma.tag.update({
        where: {
            id: tag_id,
        },
        data: {
            tag: req.body.tag,
            image_url: req.body.image_url,
        }
    })
    
    return res.json({
        status: 'success',
        message: `Updated id: ${tag_id}`,
    })
}

const deleteTag = async (req, res) => {
    const {tag_id} = req.params.id

    if(tag_id == null){
        return res.status(409).json({
            status: 'error',
            message: 'ID cannot be NULL',
        })
    }else{
        const query = await prisma.tag.delete({
            where: { id: tag_id },
          })

          return res.json({
            status: 'success',
            message: `Deleted id: ${tag_id}`
        });
    }
}

export { viewTag, createTag, editTag, deleteTag } ;
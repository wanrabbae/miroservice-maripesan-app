import pkg from '@prisma/client';
const { PrismaClient } = pkg;

const prisma = new PrismaClient();

// Withdraw Cut
const viewWithdrawCut = async (req, res) => {
    const query = await prisma.withdrawCut.findMany()

      return res.json({
        status: 'success',
        message: 'Data Showed',
        data: query
    });    
}

const editWithdrawCut = async (req, res) => {
    const query = await prisma.withdrawCut.update({
        data: {
            withdraw_cut: req.body.withdraw_cut,
        }
    })
    
    return res.json({
        status: 'success',
        message: `Update Success`,
    })
}

export { viewWithdrawCut, editWithdrawCut } ;
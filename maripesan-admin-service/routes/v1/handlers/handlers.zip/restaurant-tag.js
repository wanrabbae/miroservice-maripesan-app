import pkg from '@prisma/client';
const { PrismaClient } = pkg;

const prisma = new PrismaClient();

// Voucher
const viewVoucher = async (req, res) => {
    const query = await prisma.voucher.findMany()

      return res.json({
        status: 'success',
        message: 'Data Showed',
        data: query
    });    
}

const viewVoucherResto = async (req, res) => {
    const {restaurant_id} = req.params.id

    if(restaurant_id == null){
        return res.status(409).json({
            status: 'error',
            message: 'Restaurant_id cannot be NULL',
        })
    }else{
        const query = await prisma.voucher.findMany({
            where: { restaurant_id: restaurant_id },
          })

          return res.json({
            status: 'success',
            message: 'Data Showed',
            data: query
        });
    }
}

const createVoucher = async (req, res) => {
    const query = await prisma.voucher.create({
        data: {
            restaurant_id: req.body.restaurant_id,
            name: req.body.name,
            code: req.body.code,
            type: req.body.type,
            value: req.body.value,
            min_transaction: req.body.min_transaction,
            max_reduction: req.body.max_reduction,
            quota: req.body.quota,
            expired: req.body.expired,
        }
    })
    
    return res.json({
        status: 'success',
        message: 'Data Created',
    })
}

const editVoucher = async (req, res) => {
    const query = await prisma.voucher.update({
        data: {
            restaurant_id: req.body.restaurant_id,
            name: req.body.name,
            code: req.body.code,
            type: req.body.type,
            value: req.body.value,
            min_transaction: req.body.min_transaction,
            max_reduction: req.body.max_reduction,
            quota: req.body.quota,
            expired: req.body.expired,
        }
    })
    
    return res.json({
        status: 'success',
        message: 'Data Updated',
    })
}

const deleteVoucher = async (req, res) => {
    const {restaurant_id} = req.params.id

    if(restaurant_id == null){
        return res.status(409).json({
            status: 'error',
            message: 'Restaurant_id cannot be NULL',
        })
    }else{
        const query = await prisma.voucher.delete({
            where: { restaurant_id: restaurant_id },
          })

          return res.json({
            status: 'success',
            message: `Deleted id: ${req.params.id}`
        });
    }
}

// Banner
const viewBanner = async (req, res) => {
    const query = await prisma.banner.findMany()

      return res.json({
        status: 'success',
        message: 'Data Showed',
        data: query
    });    
}

export { viewRestaurantTag, createRestaurantTag, deleteRestaurantTag } ;